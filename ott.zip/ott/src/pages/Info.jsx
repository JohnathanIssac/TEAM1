import React from "react";
import Nav from "../Nav";

function UserInfoPage() {
    return (
        <div>
            <Nav />
        <div className="UserInfoPage">
            <h1>Account</h1>
            <br/>
            <div>
                
            </div>
        </div>
        </div>
    );
            
}

export default UserInfoPage;
