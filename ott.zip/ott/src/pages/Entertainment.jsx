import React from 'react';
import Nav from '../Nav';

function Entertainment() {
  return (
    <div>
        <Nav />
        <div className="Entertainment">
      <h1>Welcome to OTT-service Platform</h1>
      <p>This is the entertainment page content.</p>
      </div>
    </div>
  );
}

export default Entertainment;