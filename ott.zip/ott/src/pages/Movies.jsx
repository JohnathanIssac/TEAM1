import React from 'react';
import Nav from '../Nav';

function Movies() {
  return (
    <div>
        <Nav />
        <div className="Movies
    ">
      <h1>Welcome to OTT-service Platform</h1>
      <p>This is the Movies
     page content.</p>
      </div>
    </div>
  );
}

export default Movies;