import React from 'react';
import Nav from '../Nav';

function Documentary() {
  return (
    <div>
        <Nav />
        <div className="Documentary">
      <h1>Welcome to OTT-service Platform</h1>
      <p>This is the Documentary page content.</p>
      </div>
    </div>
  );
}

export default Documentary;